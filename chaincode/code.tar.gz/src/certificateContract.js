'use strict';

const { Contract } = require('fabric-contract-api');

class CertificateContract extends Contract {
    constructor() {
        super('CertificateContract');
    }

    // ✅ Step 3: Generator request certificate (status: CERTIFICATE_REQUESTED)
    async requestCertificate(ctx, certId, energyId, generatorId) {
        // Gunakan simple key untuk format yang lebih bersih
        const certKey = `CERTIFICATE_${certId}`;
        const exists = await ctx.stub.getState(certKey);
        if (exists && exists.length > 0) {
            throw new Error(`Certificate ${certId} already exists`);
        }

        // Cek apakah energy data sudah VERIFIED
        const energyKey = `ENERGY_${energyId}`;
        const energyDataBytes = await ctx.stub.getState(energyKey);
        if (!energyDataBytes || energyDataBytes.length === 0) {
            throw new Error(`EnergyData ${energyId} does not exist`);
        }

        const energyData = JSON.parse(energyDataBytes.toString());
        if (energyData.certificationStatus.status !== 'VERIFIED') {
            throw new Error(`EnergyData ${energyId} must be VERIFIED before certificate request`);
        }

        const txTimestamp = ctx.stub.getTxTimestamp();
        const requestedAt = new Date(txTimestamp.seconds * 1000).toISOString();

        // Format certificate yang profesional
        const certificate = {
            // Header Information
            documentType: 'RENEWABLE_ENERGY_CERTIFICATE',
            certificateId: certId,
            version: '1.0',
            
            // Certificate Details
            certificateInfo: {
                type: 'REC',
                status: 'CERTIFICATE_REQUESTED',
                statusDescription: 'Certificate request submitted by generator',
                issuanceStandard: 'INTERNATIONAL_REC_STANDARD_V2.0'
            },
            
            // Energy Reference
            energyReference: {
                energyDataId: energyId,
                amount: energyData.energyGeneration.amount,
                unit: energyData.energyGeneration.unit,
                sourceType: energyData.energyGeneration.sourceType,
                generationDate: energyData.energyGeneration.generationDate,
                location: energyData.energyGeneration.location
            },
            
            // Parties Involved
            parties: {
                generator: {
                    generatorId: generatorId,
                    organizationType: 'RENEWABLE_ENERGY_GENERATOR',
                    role: 'CERTIFICATE_APPLICANT'
                },
                issuer: {
                    issuerId: null,
                    organizationType: 'AUTHORIZED_CERTIFICATE_ISSUER',
                    role: 'CERTIFICATE_AUTHORITY'
                }
            },
            
            // Certificate Lifecycle
            lifecycle: {
                requestedAt: requestedAt,
                requestedBy: generatorId,
                issuedAt: null,
                issuedBy: null,
                completedAt: null,
                expiresAt: null
            },
            
            // Audit Trail
            auditTrail: {
                createdAt: requestedAt,
                createdBy: generatorId,
                lastModified: requestedAt,
                transactionId: ctx.stub.getTxID()
            },
            
            // Compliance Information
            compliance: {
                regulatoryFramework: 'INTERNATIONAL_REC_STANDARD',
                certificationBody: 'AUTHORIZED_ISSUER',
                trackingSystem: 'BLOCKCHAIN_FABRIC',
                serialNumber: `REC-${certId}-${Date.now()}`
            }
        };

        await ctx.stub.putState(certKey, Buffer.from(JSON.stringify(certificate)));
        return certificate;
    }

    // ✅ Step 4: Issuer menerbitkan certificate (status: CERTIFICATE_ISSUED)
    async issueCertificate(ctx, certId, issuerId) {
        const certKey = `CERTIFICATE_${certId}`;
        const certBytes = await ctx.stub.getState(certKey);
        if (!certBytes || certBytes.length === 0) {
            throw new Error(`Certificate ${certId} does not exist`);
        }

        const certificate = JSON.parse(certBytes.toString());
        if (certificate.certificateInfo.status !== 'CERTIFICATE_REQUESTED') {
            throw new Error(`Certificate ${certId} must be CERTIFICATE_REQUESTED before issuance`);
        }

        const txTimestamp = ctx.stub.getTxTimestamp();
        const issuedAt = new Date(txTimestamp.seconds * 1000).toISOString();
        const expiresAt = new Date(txTimestamp.seconds * 1000 + (365 * 24 * 60 * 60 * 1000)).toISOString(); // 1 year validity

        // Update dengan format profesional
        certificate.certificateInfo.status = 'CERTIFICATE_ISSUED';
        certificate.certificateInfo.statusDescription = 'Certificate officially issued by authorized issuer';
        
        certificate.parties.issuer.issuerId = issuerId;
        
        certificate.lifecycle.issuedAt = issuedAt;
        certificate.lifecycle.issuedBy = issuerId;
        certificate.lifecycle.expiresAt = expiresAt;
        
        certificate.auditTrail.lastModified = issuedAt;
        certificate.auditTrail.issuanceTxId = ctx.stub.getTxID();

        await ctx.stub.putState(certKey, Buffer.from(JSON.stringify(certificate)));
        return certificate;
    }

    // ✅ Step 5: Generator menerima certificate (status: COMPLETED)
    async completeCertificate(ctx, certId, generatorId) {
        const certKey = `CERTIFICATE_${certId}`;
        const certBytes = await ctx.stub.getState(certKey);
        if (!certBytes || certBytes.length === 0) {
            throw new Error(`Certificate ${certId} does not exist`);
        }

        const certificate = JSON.parse(certBytes.toString());
        if (certificate.certificateInfo.status !== 'CERTIFICATE_ISSUED') {
            throw new Error(`Certificate ${certId} must be CERTIFICATE_ISSUED before completion`);
        }

        // Pastikan hanya generator yang bisa complete
        if (certificate.parties.generator.generatorId !== generatorId) {
            throw new Error(`Only the original generator can complete this certificate`);
        }

        const txTimestamp = ctx.stub.getTxTimestamp();
        const completedAt = new Date(txTimestamp.seconds * 1000).toISOString();

        certificate.certificateInfo.status = 'COMPLETED';
        certificate.certificateInfo.statusDescription = 'Certificate completed and ready for trading';
        
        certificate.lifecycle.completedAt = completedAt;
        
        certificate.auditTrail.lastModified = completedAt;
        certificate.auditTrail.completionTxId = ctx.stub.getTxID();

        await ctx.stub.putState(certKey, Buffer.from(JSON.stringify(certificate)));
        return certificate;
    }

    // Request pembelian sertifikat (oleh Buyer) - untuk flow tambahan
    async createPurchaseRequest(ctx, certId, buyerId, amount) {
        const certKey = `CERTIFICATE_${certId}`;
        const certBytes = await ctx.stub.getState(certKey);
        if (!certBytes || certBytes.length === 0) {
            throw new Error(`Certificate ${certId} does not exist`);
        }

        const certificate = JSON.parse(certBytes.toString());
        if (certificate.certificateInfo.status !== 'COMPLETED') {
            throw new Error(`Certificate ${certId} must be COMPLETED before purchase`);
        }

        const txTimestamp = ctx.stub.getTxTimestamp();
        const requestedAt = new Date(txTimestamp.seconds * 1000).toISOString();

        certificate.certificateInfo.status = 'PURCHASE_REQUESTED';
        certificate.parties.buyer = {
            buyerId: buyerId,
            organizationType: 'ENERGY_BUYER',
            role: 'CERTIFICATE_PURCHASER'
        };
        certificate.purchaseDetails = {
            requestedAmount: amount,
            purchaseRequestedAt: requestedAt
        };

        certificate.auditTrail.lastModified = requestedAt;
        certificate.auditTrail.purchaseRequestTxId = ctx.stub.getTxID();

        await ctx.stub.putState(certKey, Buffer.from(JSON.stringify(certificate)));
        return certificate;
    }

    // Konfirmasi pembelian (oleh Generator)
    async confirmPurchase(ctx, certId, generatorId) {
        const certKey = `CERTIFICATE_${certId}`;
        const certBytes = await ctx.stub.getState(certKey);
        if (!certBytes || certBytes.length === 0) {
            throw new Error(`Certificate ${certId} does not exist`);
        }

        const certificate = JSON.parse(certBytes.toString());
        if (certificate.certificateInfo.status !== 'PURCHASE_REQUESTED') {
            throw new Error(`Certificate ${certId} must be in PURCHASE_REQUESTED state before confirmation`);
        }

        // Pastikan hanya generator yang bisa confirm
        if (certificate.parties.generator.generatorId !== generatorId) {
            throw new Error(`Only the certificate owner can confirm purchase`);
        }

        const txTimestamp = ctx.stub.getTxTimestamp();
        const purchasedAt = new Date(txTimestamp.seconds * 1000).toISOString();

        certificate.certificateInfo.status = 'PURCHASED';
        certificate.certificateInfo.statusDescription = 'Certificate successfully purchased and transferred';
        
        certificate.purchaseDetails.purchasedAt = purchasedAt;
        
        certificate.auditTrail.lastModified = purchasedAt;
        certificate.auditTrail.purchaseConfirmTxId = ctx.stub.getTxID();

        await ctx.stub.putState(certKey, Buffer.from(JSON.stringify(certificate)));
        return certificate;
    }

    // Ambil sertifikat by ID
    async getCertificateById(ctx, certId) {
        const certKey = `CERTIFICATE_${certId}`;
        const certBytes = await ctx.stub.getState(certKey);
        if (!certBytes || certBytes.length === 0) {
            throw new Error(`Certificate ${certId} does not exist`);
        }
        return JSON.parse(certBytes.toString());
    }

    // ✅ NEW: Ambil SEMUA sertifikat dengan format baru
    async getAllCertificates(ctx) {
        const iterator = await ctx.stub.getStateByRange('CERTIFICATE_', 'CERTIFICATE_~');
        const results = [];
        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                try {
                    const record = JSON.parse(res.value.value.toString());
                    // Hanya ambil data yang memiliki documentType RENEWABLE_ENERGY_CERTIFICATE
                    if (record.documentType === 'RENEWABLE_ENERGY_CERTIFICATE') {
                        results.push(record);
                    }
                } catch (err) {
                    console.error('Error parsing certificate data:', err);
                }
            }
            if (res.done) {
                await iterator.close();
                break;
            }
        }
        return results;
    }

    // Ambil semua sertifikat PURCHASED
    async getAllPurchasedCertificates(ctx) {
        const iterator = await ctx.stub.getStateByRange('CERTIFICATE_', 'CERTIFICATE_~');
        const results = [];
        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                try {
                    const record = JSON.parse(res.value.value.toString());
                    if (record.documentType === 'RENEWABLE_ENERGY_CERTIFICATE' && 
                        record.certificateInfo.status === 'PURCHASED') {
                        results.push(record);
                    }
                } catch (err) {
                    console.error(err);
                }
            }
            if (res.done) {
                await iterator.close();
                break;
            }
        }
        return results;
    }

    // ✅ NEW: Ambil sertifikat berdasarkan status dengan format baru
    async getCertificatesByStatus(ctx, status) {
        const iterator = await ctx.stub.getStateByRange('CERTIFICATE_', 'CERTIFICATE_~');
        const results = [];
        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                try {
                    const record = JSON.parse(res.value.value.toString());
                    if (record.documentType === 'RENEWABLE_ENERGY_CERTIFICATE' && 
                        record.certificateInfo.status === status) {
                        results.push(record);
                    }
                } catch (err) {
                    console.error('Error parsing certificate data:', err);
                }
            }
            if (res.done) {
                await iterator.close();
                break;
            }
        }
        return results;
    }

    // ✅ NEW: Ambil sertifikat berdasarkan owner/generator
    async getCertificatesByOwner(ctx, ownerId) {
        const iterator = await ctx.stub.getStateByRange('CERTIFICATE_', 'CERTIFICATE_~');
        const results = [];
        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                try {
                    const record = JSON.parse(res.value.value.toString());
                    if (record.documentType === 'RENEWABLE_ENERGY_CERTIFICATE' && 
                        (record.parties.generator.generatorId === ownerId || 
                         (record.parties.buyer && record.parties.buyer.buyerId === ownerId))) {
                        results.push(record);
                    }
                } catch (err) {
                    console.error('Error parsing certificate data:', err);
                }
            }
            if (res.done) {
                await iterator.close();
                break;
            }
        }
        return results;
    }

    // Riwayat sertifikat dengan format baru
    async getHistoryForCertificate(ctx, certId) {
        const certKey = `CERTIFICATE_${certId}`;
        const iterator = await ctx.stub.getHistoryForKey(certKey);
        const results = [];

        while (true) {
            const res = await iterator.next();
            if (res.value) {
                const txId = res.value.tx_id;
                const timestamp = new Date(res.value.timestamp.seconds * 1000).toISOString();
                const record = res.value.value.toString('utf8');

                results.push({
                    txId,
                    timestamp,
                    data: record ? JSON.parse(record) : null
                });
            }
            if (res.done) {
                await iterator.close();
                break;
            }
        }
        return results;
    }
}

module.exports = CertificateContract;
